Your first step is to go to phpMyAdmin and create a db to import my database into, which is in the database folder, it's called 'projectdb.sql', once imported you will have a couple of tables imported and some data there..

And then.. Just make sure 'projectmanager' folder (which contains all my PHP files and folders to make it work with the database) is in the below path..


-  Extract them, and placed them in the following directory: C:\xampp\htdocs\ 

- Confirm that the path C:\xampp\htdocs\projectmanager contains all of the php files and folders as per my submission 

It should work perfectly!

