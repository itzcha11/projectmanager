</main>

<footer class="site-footer">
    <div class="footer-container">
        <p>&copy; <?= date('Y') ?> Project Manager. All rights reserved.</p>
    </div>
</footer>

</body>
</html>
