These were just tools I used whilst developing, generate_hash, if you enter plaintext password, and enter the URL of the folder in your browser of the generate_hash.php file, it will generate a hash value, which you can insert into the database.

reset_password.php is a script I used to simply reset a password :).

Left them both in the directory!